import hmac, hashlib, base64, os
from dotenv import load_dotenv

load_dotenv()

def pseudonymize(x):
    return base64.urlsafe_b64encode(
        hmac.new(os.getenv("SECRET_KEY"), str(x).encode(), hashlib.sha256).digest()[:16]
    ).decode()
