#!/usr/bin/env python3
# coding: utf-8


import base64,hashlib,hmac,sys,os

import numpy as np
import pandas as pd


# -----------------------------
# CONFIG NIFI
# -----------------------------
# service NiFi, définis:
# export SECRET_KEY="...longue_cle..."
ENV_SECRET_NAME = "SECRET_KEY"


EXPECTED_COLS = [
    "ClientID","Nom","Prénom","Email","Téléphone","Adresse","Ville","CodePostal","Pays",
    "DateNaissance","Âge","Sexe","NuméroCarteCrédit","TypeCarteCrédit","DateExpirationCarte",
    "SoldeCompte","TypeClient","NombreAchats","MontantTotalAchats","DernierAchat",
    "ProduitPréféré","CatégorieProduitPréféré","FréquenceAchatMensuel","PanierMoyen",
    "ScoreFidélité","NombreRemboursements","MontantTotalRemboursé","AvisClient",
    "AbonnementNewsletter","TypePaiementFavori","StatutCompte"
]


def log(msg: str) -> None:
    """Log vers stderr (NiFi bulletin)."""
    print(msg, file=sys.stderr)


def get_secret() -> bytes:
    """Récupère la clé secrète depuis l'environnement NiFi, encode en bytes."""
    secret_str = os.getenv(ENV_SECRET_NAME)
    if not secret_str:
        raise RuntimeError(f"{ENV_SECRET_NAME} manquante (définis-la dans l'environnement NiFi)")
    return secret_str.encode("utf-8")


def pseudonymize_id(value, secret_key: bytes) -> str:
    """Pseudonymisation stable (HMAC-SHA256) -> CustomerKey court, urlsafe."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None
    msg = str(value).encode("utf-8")
    digest = hmac.new(secret_key, msg, hashlib.sha256).digest()
    short = digest[:16]
    return base64.urlsafe_b64encode(short).decode("utf-8").rstrip("=")


def coerce_numeric(series: pd.Series) -> pd.Series:
    """Convertit une série en numérique (gère virgules/espaces)."""
    s = series.astype(str).str.replace(r"\s+", "", regex=True).str.replace(",", ".", regex=False)
    return pd.to_numeric(s, errors="coerce")


def safe_to_datetime(series: pd.Series) -> pd.Series:
    """Convertit en datetime, invalides -> NaT."""
    return pd.to_datetime(series, errors="coerce")


def main() -> int:
    try:
        secret = get_secret()

        # 1) Lire depuis STDIN (le FlowFile NiFi) 
        raw_data = pd.read_csv(sys.stdin, dtype=str)

        # 2) Vérifier schéma (colonnes attendues) 
        missing = [c for c in EXPECTED_COLS if c not in raw_data.columns]
        if missing:
            raise ValueError(f"Colonnes manquantes: {missing}")

        # 3) Normalisation types 
        num_cols = ["NombreAchats","MontantTotalAchats","FréquenceAchatMensuel","PanierMoyen",
                    "ScoreFidélité","NombreRemboursements","MontantTotalRemboursé","Âge"]
        for c in num_cols:
            raw_data[c] = coerce_numeric(raw_data[c])

        raw_data["DernierAchat"] = safe_to_datetime(raw_data["DernierAchat"])
        raw_data["DateNaissance"] = safe_to_datetime(raw_data["DateNaissance"])

        # 4) Valeurs manquantes
        cat_cols = ["Pays","Sexe","TypeClient","ProduitPréféré","CatégorieProduitPréféré",
                    "AbonnementNewsletter","TypePaiementFavori","StatutCompte","TypeCarteCrédit"]
        for c in cat_cols:
            raw_data[c] = raw_data[c].fillna("Inconnu").astype(str)

        num_cols = ["NombreAchats","MontantTotalAchats","FréquenceAchatMensuel","PanierMoyen",
                  "ScoreFidélité","NombreRemboursements","MontantTotalRemboursé"]
        for c in num_cols:
            raw_data[c] = raw_data[c].fillna(raw_data[c].median())

        # 5) Doublons et incohérences (keep first, on ClientID + DernierAchat + MontantTotalAchats)
        raw_data = raw_data.drop_duplicates(subset=["ClientID","DernierAchat","MontantTotalAchats"], keep="first")
        raw_data = raw_data[raw_data["MontantTotalAchats"] >= 0]
        raw_data = raw_data[raw_data["NombreAchats"] >= 0]
        raw_data = raw_data[raw_data["PanierMoyen"] >= 0]
        raw_data = raw_data[(raw_data["Âge"].isna()) | ((raw_data["Âge"] >= 13) & (raw_data["Âge"] <= 100))]

        # 6) Généralisation (CodePostal2, TrancheAge)
        raw_data["CodePostal2"] = (
            raw_data["CodePostal"].astype(str).str.extract(r"(\d{2})", expand=False).fillna("NA")
        )

        bins = [0, 17, 24, 34, 44, 54, 64, 120]
        labels = ["0-17","18-24","25-34","35-44","45-54","55-64","65+"]
        raw_data["TrancheAge"] = (
            pd.cut(raw_data["Âge"], bins=bins, labels=labels, include_lowest=True)
              .astype(str).replace("nan","Inconnu")
        )

        # 7) Features supplémentaires (RevenuMoyenParAchat, MontantTotalDepenseParClient, NombreAchatsMensuel, PlusDe5AchatsMois)
        mt = pd.to_numeric(raw_data["MontantTotalAchats"], errors="coerce")
        na = pd.to_numeric(raw_data["NombreAchats"], errors="coerce").replace(0, np.nan)
        raw_data["RevenuMoyenParAchat"] = (
            (mt / na).replace([np.inf, -np.inf], np.nan).fillna(0).round(2)
        )

        raw_data["MontantTotalDepenseParClient"] = (
            raw_data.groupby(["ClientID", "Nom", "Prénom"])["MontantTotalAchats"].transform("sum")
        )

        raw_data["NombreAchatsMensuel"] = (
            raw_data.groupby(["ClientID", "Nom", "Prénom"])["FréquenceAchatMensuel"].transform("sum")
        )
        raw_data["PlusDe5AchatsMois"] = (raw_data["NombreAchatsMensuel"] > 5).astype(int)

        # Outliers IQR sur PanierMoyen 
        if raw_data["PanierMoyen"].notna().any():
            q1 = raw_data["PanierMoyen"].quantile(0.25)
            q3 = raw_data["PanierMoyen"].quantile(0.75)
            iqr = q3 - q1
            if pd.notna(iqr) and iqr != 0:
                low, high = q1 - 1.5*iqr, q3 + 1.5*iqr
                raw_data = raw_data[raw_data["PanierMoyen"].between(low, high)]

        # 8) RGPD: pseudonymisation et suppression PII 
        raw_data["CustomerKey"] = raw_data["ClientID"].apply(lambda x: pseudonymize_id(x, secret))

        pii_drop = ["Nom","Prénom","Email","Téléphone","Adresse","AvisClient",
                    "NuméroCarteCrédit","DateExpirationCarte","SoldeCompte",
                    "DateNaissance","Ville","CodePostal","Âge","ClientID","DernierAchat"]
        df_gold = raw_data.drop(columns=[c for c in pii_drop if c in raw_data.columns], errors="ignore")
        df_gold = df_gold.dropna(subset=["CustomerKey"])

        # Réorganiser colonnes (CustomerKey en premier) 
        cols = ["CustomerKey"] + [c for c in df_gold.columns if c != "CustomerKey"]
        df_gold = df_gold[cols]

        # 9) Écrire vers STDOUT (NiFi récupère le contenu) 
        df_gold.to_csv(sys.stdout, index=False)
        
        
        log(f"[OK] Rows in: {len(raw_data):,} | Rows out: {len(df_gold):,}")
        return 0

    except Exception as e:
        log(f"[ERROR] {type(e).__name__}: {e}") 
        return 1

if __name__ == "__main__":
    sys.exit(main())
